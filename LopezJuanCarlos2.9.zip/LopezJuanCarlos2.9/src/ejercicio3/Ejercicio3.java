/*
 * Descripcion: números pares entre el 1 y el 200 sumando de 1 en 1. 
 * Autor: Juan Carlos
 */
package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		for (int contador = 1; contador <= 200; contador++) {
			if (contador % 2 == 0) {
				System.out.println(contador);
				}
	        }

	}

}
